/*    */ package mypack1;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GamePanel
/*    */   extends JPanel
/*    */   implements ActionListener, Runnable
/*    */ {
/*    */   JButton start;
/*    */   JPanel buttonPanel;
/*    */   BallPanel ballPanel;
/*    */   public static boolean drawFlag = false;
/*    */   public static final int UPDATE_Time = 20;
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public GamePanel() {
/* 26 */     drawFlag = false;
/* 27 */     this.start = new JButton("开始游戏");
/* 28 */     this.buttonPanel = new JPanel();
/* 29 */     this.buttonPanel.add(this.start);
/* 30 */     this.buttonPanel.setBackground(Color.cyan);
/*    */     
/* 32 */     setLayout(new BorderLayout());
/* 33 */     setPreferredSize(new Dimension(700, 500));
/* 34 */     add(this.buttonPanel, "North");
/*    */     
/* 36 */     this.ballPanel = new BallPanel();
/* 37 */     this.ballPanel.setBackground(Color.white);
/* 38 */     add(this.ballPanel);
/* 39 */     this.start.addActionListener(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent arg0) {
/* 48 */     String cmd = arg0.getActionCommand();
/*    */     
/* 50 */     if (cmd.equals("开始游戏")) {
/* 51 */       startGame();
/*    */     }
/*    */   }
/*    */   
/*    */   public void startGame() {
/* 56 */     int x = 0;
/* 57 */     int y = getHeight() / 2;
/* 58 */     Ball ball = new Ball(x, y, 1.0D, 2, 0, Color.blue);
/* 59 */     this.ballPanel.setBall(ball);
/* 60 */     drawFlag = true;
/*    */     
/* 62 */     (new Thread(ball)).start();
/* 63 */     (new Thread(this)).start();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     while (true) {
/*    */       try {
/* 71 */         Thread.sleep(20L);
/* 72 */       } catch (InterruptedException e) {
/*    */         
/* 74 */         e.printStackTrace();
/*    */       } 
/* 76 */       this.ballPanel.repaint();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Users\mxy\Documents\Tencent Files\1729529198\FileRecv\User Data\运行轨迹.jar!\mypack1\GamePanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */