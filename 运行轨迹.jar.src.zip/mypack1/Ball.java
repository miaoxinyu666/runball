/*     */ package mypack1;
/*     */ 
/*     */ import java.awt.Color;
/*     */ 
/*     */ public class Ball
/*     */   implements Runnable {
/*     */   int x;
/*     */   int y;
/*   9 */   int r = 10;
/*     */   double k;
/*     */   int speed;
/*     */   Color fillColor;
/*  13 */   int turnFlag = 0;
/*     */   boolean threadFlag = true;
/*  15 */   int count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ball() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public Ball(int x, int y, double k, int speed, int turnFlag, Color fillColor) {
/*  25 */     this.x = x;
/*  26 */     this.y = y;
/*  27 */     this.k = k;
/*  28 */     this.speed = speed;
/*  29 */     this.turnFlag = 0;
/*  30 */     this.fillColor = fillColor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  36 */     while (this.threadFlag) {
/*     */       try {
/*  38 */         Thread.sleep(20L);
/*  39 */       } catch (InterruptedException e) {
/*     */         
/*  41 */         e.printStackTrace();
/*     */       } 
/*     */       
/*  44 */       if (MainFrame.pathFlag == 1) {
/*  45 */         move1();
/*     */       }
/*  47 */       if (MainFrame.pathFlag == 2) {
/*  48 */         move3();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void move2() {
/*  55 */     if (this.turnFlag == 0) {
/*  56 */       this.x++;
/*  57 */       this.y--;
/*  58 */       if (this.y <= 0) this.turnFlag = 1;
/*     */     
/*     */     } 
/*  61 */     if (this.turnFlag == 1) {
/*  62 */       this.x++;
/*  63 */       this.y++;
/*  64 */       if (this.y >= BallPanel2.h) this.turnFlag = 2;
/*     */     
/*     */     } 
/*  67 */     if (this.turnFlag == 2) {
/*  68 */       this.x++;
/*  69 */       this.y--;
/*  70 */       if (this.x >= BallPanel2.w) this.turnFlag = 3;
/*     */     
/*     */     } 
/*  73 */     if (this.turnFlag == 3) {
/*  74 */       this.x--;
/*  75 */       this.y--;
/*  76 */       if (this.y <= 0) this.turnFlag = 4;
/*     */     
/*     */     } 
/*  79 */     if (this.turnFlag == 4) {
/*  80 */       this.x--;
/*  81 */       this.y++;
/*  82 */       if (this.x <= 0) {
/*  83 */         this.x = 0;
/*  84 */         this.y = BallPanel2.h / 2;
/*  85 */         this.turnFlag = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move3() {
/*  93 */     int x0 = this.x, y0 = this.y;
/*  94 */     if (this.turnFlag == 0) {
/*  95 */       this.x++;
/*  96 */       this.y = (int)(this.k * (this.x - x0) + y0);
/*     */     } 
/*  98 */     if (this.turnFlag == 1) {
/*  99 */       this.x--;
/* 100 */       this.y = (int)(this.k * (this.x - x0) + y0);
/*     */     } 
/*     */     
/* 103 */     if (this.x >= BallPanel2.w) {
/* 104 */       this.turnFlag = 1;
/*     */     }
/* 106 */     if (this.x <= 0)
/* 107 */       this.turnFlag = 0; 
/* 108 */     if (this.x <= 0 || this.x >= BallPanel2.w || 
/* 109 */       this.y <= 0 || this.y >= BallPanel2.h) {
/* 110 */       this.k = -this.k;
/* 111 */       this.count++;
/* 112 */       if (this.count >= 10)
/* 113 */         this.threadFlag = false; 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void move1() {
/* 118 */     this.x++;
/* 119 */     this.y = (int)(200.0D + 100.0D * Math.sin(this.x * Math.PI / 180.0D));
/* 120 */     if (this.x >= 800) this.x = 0; 
/*     */   }
/*     */ }


/* Location:              D:\Users\mxy\Documents\Tencent Files\1729529198\FileRecv\User Data\运行轨迹.jar!\mypack1\Ball.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */