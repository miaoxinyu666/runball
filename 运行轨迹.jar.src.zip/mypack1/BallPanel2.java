/*     */ package mypack1;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Point;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BallPanel2
/*     */   extends JPanel
/*     */ {
/*     */   Ball ball;
/*     */   static int h;
/*     */   static int w;
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public void setBall(Ball ball) {
/*  94 */     this.ball = ball;
/*  95 */     h = getHeight();
/*  96 */     w = getWidth();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/* 102 */     Point p0 = new Point();
/* 103 */     Point p = new Point();
/* 104 */     super.paintComponent(g);
/* 105 */     Graphics2D g2d = (Graphics2D)g;
/* 106 */     Stroke s = new BasicStroke(2.0F, 0, 2);
/* 107 */     g2d.setStroke(s);
/* 108 */     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */     
/* 111 */     if (Path2Panel.drawFlag) {
/* 112 */       p0.x = 0; p0.y = h / 2;
/* 113 */       double k = 1.0D;
/*     */       
/* 115 */       for (int a = 1; a <= 10; a++) {
/* 116 */         p = getNextPoint(p0, k);
/* 117 */         g2d.drawLine(p0.x, p0.y, p.x, p.y);
/*     */         
/* 119 */         k = -k;
/* 120 */         p0.x = p.x; p0.y = p.y;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 125 */       g2d.setPaint(this.ball.fillColor);
/* 126 */       g2d.fillOval(this.ball.x - this.ball.r, this.ball.y - this.ball.r, this.ball.r * 2, this.ball.r * 2);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Point getPoint(Point p0, Point p, double k) {
/* 131 */     if (p.y == -1) {
/* 132 */       p.y = (int)(k * (p.x - p0.x)) + p0.y;
/*     */     } else {
/*     */       
/* 135 */       p.x = (int)((p.y - p0.y) / k) + p0.x;
/*     */     } 
/* 137 */     return p;
/*     */   }
/*     */   
/*     */   public Point getNextPoint(Point p0, double k) {
/* 141 */     Point[] p = new Point[4];
/* 142 */     Point p1 = new Point();
/*     */     int i;
/* 144 */     for (i = 0; i < p.length; i++) {
/* 145 */       p[i] = new Point();
/*     */     }
/*     */     
/* 148 */     (p[0]).y = 0;
/* 149 */     (p[0]).x = (int)(((p[0]).y - p0.y) / k + p0.x);
/*     */ 
/*     */     
/* 152 */     (p[1]).y = h;
/* 153 */     (p[1]).x = (int)(((p[1]).y - p0.y) / k + p0.x);
/*     */ 
/*     */ 
/*     */     
/* 157 */     (p[2]).x = w;
/* 158 */     (p[2]).y = (int)(k * ((p[2]).x - p0.x) + p0.y);
/*     */ 
/*     */ 
/*     */     
/* 162 */     (p[3]).x = 0;
/* 163 */     (p[3]).y = (int)(k * ((p[3]).x - p0.x) + p0.y);
/*     */ 
/*     */     
/* 166 */     for (i = 0; i < p.length; i++) {
/* 167 */       if ((p[i]).x != p0.x || (p[i]).y != p0.y)
/*     */       {
/* 169 */         if ((p[i]).x >= 0 && (p[i]).x <= w && 
/* 170 */           (p[i]).y >= 0 && (p[i]).y <= h)
/* 171 */           p1 = p[i]; 
/*     */       }
/*     */     } 
/* 174 */     return p1;
/*     */   }
/*     */ }


/* Location:              D:\Users\mxy\Documents\Tencent Files\1729529198\FileRecv\User Data\运行轨迹.jar!\mypack1\BallPanel2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */