/*    */ package mypack1;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JMenu;
/*    */ import javax.swing.JMenuBar;
/*    */ import javax.swing.JMenuItem;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ public class MainFrame
/*    */   extends JFrame
/*    */   implements ActionListener {
/*    */   JPanel contentPane;
/*    */   JLabel backGround;
/*    */   ImageIcon icon;
/*    */   JMenuBar bar;
/*    */   JMenu m1;
/* 21 */   String[] m1_item = new String[] { "轨迹1", "轨迹2", "退出" };
/*    */   
/*    */   static int pathFlag;
/*    */   
/*    */   private static final long serialVersionUID = -6420530212536145608L;
/*    */   
/*    */   public MainFrame() {
/* 28 */     setSize(800, 600);
/* 29 */     setLocationRelativeTo(null);
/* 30 */     setDefaultCloseOperation(3);
/*    */     
/* 32 */     this.contentPane = (JPanel)getContentPane();
/* 33 */     this.icon = new ImageIcon("./image/back.jpg");
/* 34 */     this.backGround = new JLabel(this.icon);
/* 35 */     this.backGround.setSize(this.icon.getIconWidth(), this.icon.getIconHeight());
/* 36 */     this.contentPane.add(this.backGround);
/*    */     
/* 38 */     addMenu();
/* 39 */     setResizable(false);
/* 40 */     setVisible(true);
/*    */   }
/*    */   
/*    */   public void addMenu() {
/* 44 */     this.bar = new JMenuBar();
/* 45 */     setJMenuBar(this.bar);
/* 46 */     this.m1 = new JMenu("功能菜单");
/* 47 */     this.bar.add(this.m1);
/* 48 */     for (int i = 0; i < this.m1_item.length; i++) {
/* 49 */       JMenuItem item = new JMenuItem(this.m1_item[i]);
/* 50 */       item.addActionListener(this);
/* 51 */       this.m1.add(item);
/*    */     } 
/* 53 */     this.m1.insertSeparator(0);
/* 54 */     this.m1.insertSeparator(3);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent arg0) {
/* 66 */     String cmd = arg0.getActionCommand();
/*    */     
/* 68 */     if (cmd.equals("轨迹1")) {
/* 69 */       pathFlag = 1;
/* 70 */       path1();
/*    */     } 
/*    */     
/* 73 */     if (cmd.equals("轨迹2")) {
/* 74 */       pathFlag = 2;
/* 75 */       path2();
/*    */     } 
/*    */     
/* 78 */     if (cmd.equals("退出")) {
/* 79 */       System.exit(0);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void path2() {
/* 89 */     this.contentPane.removeAll();
/* 90 */     this.contentPane.add(new Path2Panel());
/* 91 */     setVisible(true);
/*    */   }
/*    */ 
/*    */   
/*    */   private void path1() {
/* 96 */     this.contentPane.removeAll();
/* 97 */     this.contentPane.add(new GamePanel());
/* 98 */     setVisible(true);
/*    */   }
/*    */ }


/* Location:              D:\Users\mxy\Documents\Tencent Files\1729529198\FileRecv\User Data\运行轨迹.jar!\mypack1\MainFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */