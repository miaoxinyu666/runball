/*    */ package mypack1;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Path2Panel
/*    */   extends JPanel
/*    */   implements ActionListener, Runnable
/*    */ {
/*    */   JButton start;
/*    */   JPanel buttonPanel;
/*    */   BallPanel2 ballPanel;
/*    */   public static boolean drawFlag = false;
/*    */   public static final int UPDATE_Time = 20;
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public Path2Panel() {
/* 29 */     drawFlag = false;
/* 30 */     this.start = new JButton("开始游戏");
/* 31 */     this.buttonPanel = new JPanel();
/* 32 */     this.buttonPanel.add(this.start);
/* 33 */     this.buttonPanel.setBackground(Color.cyan);
/*    */     
/* 35 */     setLayout(new BorderLayout());
/* 36 */     setPreferredSize(new Dimension(700, 500));
/* 37 */     add(this.buttonPanel, "North");
/*    */     
/* 39 */     this.ballPanel = new BallPanel2();
/* 40 */     this.ballPanel.setBackground(Color.white);
/* 41 */     add(this.ballPanel);
/* 42 */     this.start.addActionListener(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent arg0) {
/* 51 */     String cmd = arg0.getActionCommand();
/*    */     
/* 53 */     if (cmd.equals("开始游戏")) {
/* 54 */       startGame();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void startGame() {
/* 60 */     Ball ball = new Ball(0, 0, 1.0D, 2, 0, Color.blue);
/* 61 */     this.ballPanel.setBall(ball);
/* 62 */     ball.x = 0;
/* 63 */     ball.y = BallPanel2.h / 2;
/* 64 */     drawFlag = true;
/*    */     
/* 66 */     (new Thread(ball)).start();
/* 67 */     (new Thread(this)).start();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     while (true) {
/*    */       try {
/* 75 */         Thread.sleep(20L);
/* 76 */       } catch (InterruptedException e) {
/*    */         
/* 78 */         e.printStackTrace();
/*    */       } 
/* 80 */       this.ballPanel.repaint();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Users\mxy\Documents\Tencent Files\1729529198\FileRecv\User Data\运行轨迹.jar!\mypack1\Path2Panel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */